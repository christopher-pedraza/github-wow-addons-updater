local guide = WoWPro:RegisterGuide('Cag_HRFD', 'Leveling', 'Orgrimmar', 'WowPro Team', 'Horde', 1)
WoWPro:GuideLevels(guide,35, 44)
WoWPro:GuideName(guide, 'Dungeon: Razorfen Downs')
WoWPro:GuideSteps(guide, function()
return [[


]]
end)