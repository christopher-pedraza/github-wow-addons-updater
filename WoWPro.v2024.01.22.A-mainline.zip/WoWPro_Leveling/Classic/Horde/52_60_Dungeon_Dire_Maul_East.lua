local guide = WoWPro:RegisterGuide('Cag_HDME', 'Leveling', 'Orgrimmar', 'WowPro Team', 'Horde', 1)
WoWPro:GuideLevels(guide,52, 60)
WoWPro:GuideName(guide, 'Dungeon: Dire Maul East')
WoWPro:GuideSteps(guide, function()
return [[


]]
end)