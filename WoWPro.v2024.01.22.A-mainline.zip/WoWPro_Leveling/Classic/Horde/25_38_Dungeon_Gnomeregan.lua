local guide = WoWPro:RegisterGuide('Cag_HGnomer', 'Leveling', 'Orgrimmar', 'WowPro Team', 'Horde', 1)
WoWPro:GuideLevels(guide,25, 38)
WoWPro:GuideName(guide, 'Dungeon: Gnomeregan')
WoWPro:GuideSteps(guide, function()
return [[


]]
end)