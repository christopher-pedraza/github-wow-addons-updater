local guide = WoWPro:RegisterGuide('Cag_HDMN', 'Leveling', 'Orgrimmar', 'WowPro Team', 'Horde', 1)
WoWPro:GuideLevels(guide,54, 60)
WoWPro:GuideName(guide, 'Dungeon: Dire Maul North')
WoWPro:GuideSteps(guide, function()
return [[


]]
end)