local guide = WoWPro:RegisterGuide('Cag_HRFK', 'Leveling', 'Orgrimmar', 'WowPro Team', 'Horde', 1)
WoWPro:GuideLevels(guide,25, 34)
WoWPro:GuideName(guide, 'Dungeon: Razorfen Kraul')
WoWPro:GuideSteps(guide, function()
return [[


]]
end)