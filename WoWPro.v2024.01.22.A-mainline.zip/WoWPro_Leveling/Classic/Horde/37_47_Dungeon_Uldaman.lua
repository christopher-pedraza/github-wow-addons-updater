local guide = WoWPro:RegisterGuide('Cag_HUlda', 'Leveling', 'Orgrimmar', 'WowPro Team', 'Horde', 1)
WoWPro:GuideLevels(guide,37, 47)
WoWPro:GuideName(guide, 'Dungeon: Uldaman')
WoWPro:GuideSteps(guide, function()
return [[


]]
end)