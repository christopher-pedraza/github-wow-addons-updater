local guide = WoWPro:RegisterGuide('Cag_HZF', 'Leveling', 'Orgrimmar', 'WowPro Team', 'Horde', 1)
WoWPro:GuideLevels(guide,40, 50)
WoWPro:GuideName(guide, 'Dungeon: Zul_Farrak')
WoWPro:GuideSteps(guide, function()
return [[


]]
end)