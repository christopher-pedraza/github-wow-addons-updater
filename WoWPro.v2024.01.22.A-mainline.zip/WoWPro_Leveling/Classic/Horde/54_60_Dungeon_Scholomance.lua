local guide = WoWPro:RegisterGuide('Cag_HScholo', 'Leveling', 'Orgrimmar', 'WowPro Team', 'Horde', 1)
WoWPro:GuideLevels(guide,54, 60)
WoWPro:GuideName(guide, 'Dungeon: Scholomance')
WoWPro:GuideSteps(guide, function()
return [[


]]
end)