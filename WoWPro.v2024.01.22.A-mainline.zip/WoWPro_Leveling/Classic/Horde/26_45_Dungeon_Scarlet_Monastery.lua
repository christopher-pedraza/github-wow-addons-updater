local guide = WoWPro:RegisterGuide('Cag_HSM', 'Leveling', 'Orgrimmar', 'WowPro Team', 'Horde', 1)
WoWPro:GuideLevels(guide,26, 45)
WoWPro:GuideName(guide, 'Dungeon: Scarlet Monastery')
WoWPro:GuideSteps(guide, function()
return [[


]]
end)