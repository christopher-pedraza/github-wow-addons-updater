local guide = WoWPro:RegisterGuide('Cag_HUBRS', 'Leveling', 'Orgrimmar', 'WowPro Team', 'Horde', 1)
WoWPro:GuideLevels(guide,25, 38)
WoWPro:GuideName(guide, 'Dungeon: Upper Blackrock Spire')
WoWPro:GuideSteps(guide, function()
return [[


]]
end)