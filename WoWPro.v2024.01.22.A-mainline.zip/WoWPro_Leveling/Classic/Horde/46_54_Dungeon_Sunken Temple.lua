local guide = WoWPro:RegisterGuide('Cag_HST', 'Leveling', 'Orgrimmar', 'WowPro Team', 'Horde', 1)
WoWPro:GuideLevels(guide,46, 54)
WoWPro:GuideName(guide, 'Dungeon: Sunken Temple')
WoWPro:GuideSteps(guide, function()
return [[


]]
end)