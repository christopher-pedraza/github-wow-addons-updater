local guide = WoWPro:RegisterGuide('Cag_HBRD', 'Leveling', 'Orgrimmar', 'WowPro Team', 'Horde', 1)
WoWPro:GuideLevels(guide,50, 60)
WoWPro:GuideName(guide, 'Dungeon: Blackrock Depths')
WoWPro:GuideSteps(guide, function()
return [[


]]
end)