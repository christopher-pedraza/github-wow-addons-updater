local guide = WoWPro:RegisterGuide('Cag_HStrat', 'Leveling', 'Orgrimmar', 'WowPro Team', 'Horde', 1)
WoWPro:GuideLevels(guide,56, 60)
WoWPro:GuideName(guide, 'Dungeon: Stratholme')
WoWPro:GuideSteps(guide, function()
return [[


]]
end)