local guide = WoWPro:RegisterGuide('Cag_HST', 'Leveling', 'Stormwind', 'WowPro Team', 'Alliance', 1)
WoWPro:GuideLevels(guide,46, 54)
WoWPro:GuideName(guide, 'Dungeon: Sunken Temple')
WoWPro:GuideSteps(guide, function()
return [[

N This guide is WIP. Comming soon.|
]]
end)