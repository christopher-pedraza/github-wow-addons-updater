local guide = WoWPro:RegisterGuide('Cag_HDME', 'Leveling', 'Stormwind', 'WowPro Team', 'Alliance', 1)
WoWPro:GuideLevels(guide,52, 60)
WoWPro:GuideName(guide, 'Dungeon: Dire Maul East')
WoWPro:GuideSteps(guide, function()
return [[
N This guide is WIP. Comming soon.|

]]
end)