local guide = WoWPro:RegisterGuide('Cag_ARFK', 'Leveling', 'Stormwind', 'WowPro Team', 'Alliance', 1)
WoWPro:GuideLevels(guide,25, 34)
WoWPro:GuideName(guide, 'Dungeon: Razorfen Kraul')
WoWPro:GuideSteps(guide, function()
return [[
N This guide is WIP. Comming soon.|

]]
end)