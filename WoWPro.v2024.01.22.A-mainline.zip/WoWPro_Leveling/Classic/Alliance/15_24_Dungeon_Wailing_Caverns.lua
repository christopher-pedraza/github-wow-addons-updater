local guide = WoWPro:RegisterGuide('Ludovicus_AWC', 'Leveling', 'The Barrens', 'Elidion', 'Alliance', 1)
WoWPro:GuideLevels(guide,15, 24)
WoWPro:GuideName(guide, 'Dungeon: Wailing Caverns')
WoWPro:GuideSteps(guide, function()
return [[
N This guide is WIP. Comming soon.|
]]
end)
