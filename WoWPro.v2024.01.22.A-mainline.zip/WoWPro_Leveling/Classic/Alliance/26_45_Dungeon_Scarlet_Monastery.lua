local guide = WoWPro:RegisterGuide('Cag_ASM', 'Leveling', 'Stormwind', 'WowPro Team', 'Alliance', 1)
WoWPro:GuideLevels(guide,26, 45)
WoWPro:GuideName(guide, 'Dungeon: Scarlet Monastery')
WoWPro:GuideSteps(guide, function()
return [[

N This guide is WIP. Comming soon.|
]]
end)