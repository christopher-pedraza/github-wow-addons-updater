local guide = WoWPro:RegisterGuide('Cag_HLBRS', 'Leveling', 'Stormwind', 'WowPro Team', 'Alliance', 1)
WoWPro:GuideLevels(guide,54, 60)
WoWPro:GuideName(guide, 'Dungeon: Lower Blackrock Spire')
WoWPro:GuideSteps(guide, function()
return [[
N This guide is WIP. Comming soon.|

]]
end)