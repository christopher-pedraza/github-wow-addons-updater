local guide = WoWPro:RegisterGuide('Cag_AStocks', 'Leveling', 'Orgrimmar', 'WowPro Team', 'Alliance', 1)
WoWPro:GuideLevels(guide,22, 30)
WoWPro:GuideName(guide, 'Dungeon: The Stockade')
WoWPro:GuideSteps(guide, function()
return [[

N This guide is WIP. Comming soon.|
]]
end)