local guide = WoWPro:RegisterGuide('Cag_HUBRS', 'Leveling', 'Stormwind', 'WowPro Team', 'Alliance', 1)
WoWPro:GuideLevels(guide,25, 38)
WoWPro:GuideName(guide, 'Dungeon: Upper Blackrock Spire')
WoWPro:GuideSteps(guide, function()
return [[

N This guide is WIP. Comming soon.|

]]
end)